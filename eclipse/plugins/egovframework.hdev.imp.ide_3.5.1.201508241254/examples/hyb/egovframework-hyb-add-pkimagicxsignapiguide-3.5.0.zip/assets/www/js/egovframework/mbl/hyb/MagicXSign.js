////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	MagicXSign.js
//  MagicXSign Phonegap JavaScript
//	
//	Created by tamrin on 2012.04.20
//	Copyright 2012 DreamSecurity All rights reserved. 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function MagicXSign_makeQueryString( form ) {
	var name  =  new Array(form.elements.length); 
	var value =  new Array(form.elements.length); 
	var flag  = false;
	var j     = 0;
	var plain_text ="";

	len = form.elements.length; 
	
	for (i = 0; i < len; i++) {

		if( (form.elements[i].type != "button") && (form.elements[i].type != "reset") && (form.elements[i].type != "submit") ) {
			if (form.elements[i].type == "radio" || form.elements[i].type == "checkbox") { 
				if (form.elements[i].checked == true) {
					name[j] = form.elements[i].name; 
					value[j] = form.elements[i].value;
					j++;
				}
			}else {
				name[j] = form.elements[i].name; 
				if (form.elements[i].type == "select-one") {
					var ind = form.elements[i].selectedIndex;
					if (form.elements[i].options[ind].value != '')
						value[j] = form.elements[i].options[ind].value;
					else
						value[j] = form.elements[i].options[ind].text;
				}else{
					value[j] = form.elements[i].value;
				}
				j++;
			}
		}
	}

	for (i = 0; i < j; i++) {
		if (flag)
			plain_text += "&";
		else
			flag = true;
		plain_text += name[i] ;
		plain_text += "=";
		plain_text += value[i];
	}
	console.log(plain_text);
	return plain_text;
}


function MagicXSign_CheckAndroid()
{
	var uagent = navigator.userAgent.toLowerCase(); //유저에이전트 문자열을 얻어 소문자로 변환

	//모바일 user-agent 판단
	var ret1 = uagent.search("android");
//	var ret2 = uagent.search("iphone");
	if(ret1 > -1)
		return 0;		// 안드로이드 단말
	
	return 1;			// 안드로이드가 아닌 단말
}




// 플렛폼 모드 설정  ios / android
var MAGICXSIGN_PLATFORM;
if (MagicXSign_CheckAndroid() == 0)
	MAGICXSIGN_PLATFORM="android";
else
	MAGICXSIGN_PLATFORM="ios";
	


// 아이폰, 안드로이드 의 기본 폰겟 구조체... 의 대소문자가 틀리다 -_-;
var xsigncordova = null;


if(MAGICXSIGN_PLATFORM == "ios")
{
    xsigncordova = Cordova;
} else if (MAGICXSIGN_PLATFORM == "android")
{
    xsigncordova = cordova;
}


function MagicXSignPlugin() { 
  
} 


MagicXSignPlugin.prototype.init = function(debugflag) {
	return xsigncordova.exec(function(result){}, function(result){}, "MagicXSignPlugin", "init", ["["+debugflag+"]"]); 
};

MagicXSignPlugin.prototype.getcertcount = function(win, fail, name) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "getcert", name); 
};


// 인증서 정보 요청
// 버전				: "ver"
// 일련번호			: "sn"
// 발급자			: "issuedn"
// 만료일(시작)		: "start"
// 만료일(끝)		: "end"
// 주체자			: "subjdn"
// 공개키 알고리즘	: "pubkeyalgo"
// 공개키			: "pubkey"
// 기관 정보 접근		: "aia"
// 발급자 키식별자	: "aki"
// 주체자 키식별자	: "ski"
// 키사용			: "keyuse"
// 정책				: "policy"
// 정책 ID			: "policyid"
// 주체 대채이름		: "subaltname"
// CRL 위치			: "crl"
MagicXSignPlugin.prototype.getcertlist= function(win, fail, certtypearg) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "getcertlist", [certtypearg]); 
};


// 인증서 삭제
// index 	: 선택된 인증서 index
MagicXSignPlugin.prototype.certdel= function(win, fail, certindex) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "certdel", ["["+certindex+"]"]); 
};


// 인증서 비밀번호 변경
// index	 	: 선택된 인증서 index
// oldpassword 	: 기존 비밀번호
// newpassword  : 신규 비밀번호 
MagicXSignPlugin.prototype.certchagepassword= function(win, fail, passdata) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "certchagepassword", ["["+passdata+"]"] ); 
};


// SignData 생성
// certindex 	: 선택된 인증서 index
// certpassword	: 선택된 인증서  Password
// uservid	 	: 선택된 인증서 주민번호 
// plaintext	: 암호 원문
MagicXSignPlugin.prototype.makesign= function(win, fail, e2edata) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "makesign", ["["+e2edata +"]" ]); 
};




// 인증서 이동 : 이동 코드 생성
// phoneno 		: 폰번호 (LOG볼때만  필요.. 임의의 String 을 넣어도 괜찬음)
// serverip		: 인증서 이동서버 IP
// serverport	: 인증서 이동서버 Port
// serviceid	: 인증서 이동 서비스 ID
MagicXSignPlugin.prototype.mrs_makecode= function(win, fail, e2edata) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "mrs_makecode", ["["+e2edata +"]" ]); 
};

// 인증서 이동 : 인증서 이동 대기
MagicXSignPlugin.prototype.mrs_waitcert= function(win, fail, e2edata) {
	return xsigncordova.exec(win, fail, "MagicXSignPlugin", "mrs_waitcert", [e2edata]); 
};



// 인증서 이동 : 인증서 이동 대기
MagicXSignPlugin.prototype.mrs_stopcertmove= function() {
	return xsigncordova.exec(function(result){}, function(result){}, "MagicXSignPlugin", "mrs_stopcertmove", [""]); 
};





// 20120704-tamrin
// iOS 전용 함수
// 올레인증서와 연동하여 인증서를 가져오는 기능을 제공한다

// 올레인증서 인스톨 유무 확인
MagicXSignPlugin.prototype.ollecert_check= function(win,fail) {
	if(MAGICXSIGN_PLATFORM == "ios")
        return xsigncordova.exec(win,fail, "MagicXSignPlugin", "ollecert_check", [""]); 
};


// 올레인증서 인스톨
MagicXSignPlugin.prototype.ollecert_install= function() {
	if(MAGICXSIGN_PLATFORM == "ios")
        return xsigncordova.exec(function(result){}, function(result){}, "MagicXSignPlugin", "ollecert_install", [""]); 
};


// 올레인증서에서 인증서 가져오기
MagicXSignPlugin.prototype.ollecert_getcert= function(win,fail,certindex) {
	if(MAGICXSIGN_PLATFORM == "ios")
        return xsigncordova.exec(win, fail, "MagicXSignPlugin", "ollecert_getcert", [certindex]); 
   
};




// 아이폰, 안드로이드 겸용으로 쓰기 위한 코딩
{    
	if(MAGICXSIGN_PLATFORM == "ios")
    {
       Cordova.addConstructor(function() {
                              if(!window.plugins)               window.plugins = {};
                              if(!window.plugins.magicxsign)    window.plugins.magicxsign = new MagicXSignPlugin();
                              });
    } else if (MAGICXSIGN_PLATFORM == "android")
    {
       cordova.addConstructor(function() {
                              cordova.addPlugin('magicxsign', new MagicXSignPlugin());
                              });
    }
}



