/** 
 * @fileoverview 모바일 전자정부 하이브리드 앱 PKIMagicXSign API 가이드 프로그램 JavaScript
 * JavaScript. 
 *
 * @author 나신일
 * @version 1.0 
 */

/**
 * iScroll 객체 생성
 * @type iScroll
 */
var myScroll;

/*********************************************************
 * HTML 및 이벤트 관련 함수
 *********************************************************/

/**
 * 화면을 위한 관련 이벤트
 */
$(function(){
    $.validator.setDefaults({
        submitHandler: function() { 
            if($.mobile.activePage.is('#login')) {
                //3G 사용시 과금이 발생 할 수 있다는 경고 메시지 표시
                if(!fn_egov_network_check(false)) {
                    return;
                }
                // 인증서 인증
                fn_egov_login_member();
            }
        }
    });
    
    // validation check
    $("#loginForm").validate();
    
    $(document).on("pageshow", "#importanceList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapperInfo');
    });
    
    $(document).on("pageshow", "#certList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapper');
    });
    
    $(document).on("pageshow", "#loginInfoList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapperList');
    });
});

/**
 * PhoneGap 초기화 이벤트에서 호출하는 function
 * @returns iscroll 과 Back 버튼 event 추가
 * @type
*/
function DeviceAPIInit() {
    loaded('wrapperInfo');
    document.addEventListener("backbutton", backKeyDown, false);
    
    // magicxsign 모듈 초기화
    window.plugins.magicxsign.init("true");	
}

/**
 * Android Back 버튼 클릭 이벤트 function.
 * @returns intro or importanceList 화면에서 종료하고 나머지 화면에선 back 처리
 * @type
*/
function backKeyDown(e) {
    if($.mobile.activePage.is('#intro') || $.mobile.activePage.is('#importanceList')){
        
        e.preventDefault();
        navigator.app.exitApp();

    }else{
        navigator.app.backHistory();
    }
}

/**
 * iScroll 적용
 * @returns 
 * @type 
 */
function loaded(scrollTarget) {
    
    // Use this for high compatibility (iDevice + Android)
    setTimeout(function () {
        myScroll = new iScroll(scrollTarget, {
            onBeforeScrollStart : function(e) {
                var target = e.target;
                while (target.nodeType != 1)
                    target = target.parentNode;
    
                if (target.tagName != 'SELECT' && target.tagName != 'INPUT'
                        && target.tagName != 'TEXTAREA')
                    e.preventDefault();
            }
        });
    });

    document.addEventListener('touchmove', function(e) {
        e.preventDefault();
    }, false);
}

/**
 * 서명 성공 Callback function.
 * @returns 서명이 성공하면 사인데이터를 서버에 전달 한다.
 * @type 
*/
function fn_egov_makesign_ok(arg)
{
    console.log('DeviceAPIGuide fn_egov_makesign_ok Success');
    var jsonobj = JSON.parse(arg);
    
    // jsonobj.sign에서 서면 값, jsonobj.vidRandom에서 본인확인을 위한 VID Random값을 가져올 수 있다.
    var signedData = jsonobj.sign;	
    
    var url = "/pki/xml/addPKIInfo.do";
    var acceptType = "xml";
    var params = {uuid :  device.uuid,			
            sign: signedData,
            entrprsSeCode: 'PKI01'};
    
    alert('Http Method:POST\nacceptType:'+ acceptType + '\n요청데이터:' + JSON.stringify(params));
    
    // get the data from server
    window.plugins.EgovInterface.post(url,acceptType, params, function(xmldata) {		
        console.log('DeviceAPIGuide fn_egov_makesign_ok request Complete');
        alert('응답데이터:' + xmldata)
        if($(xmldata).find("resultState").text() == "OK"){				
            window.history.go(-2);
        }else{
            jAlert($(xmldata).find("resultMessage").text(), '오류', 'c');
        }
        
    });	
    
    document.getElementById("innerhtmlArea").innerHTML= "SendResult : <br>"+sResult+"<br><br>";
}

/**
 * 서명 실패 Callback function.
 * @returns 
 * @type
*/
function fn_egov_makesign_fail(arg)
{
    console.log('DeviceAPIGuide fn_egov_makesign_fail Fail');
    // 서명 실패 
    // 비일번호가 틀린것으로 간주합니다.
    alert('인증서 비밀번호가 틀렸습니다.');	
}

/**
 * 인증서 리스트 호출 성공 Callback function.
 * @returns 리스트 생성
 * @type
*/
function fn_egov_getcertlistSuccess(arg) {
    console.log('DeviceAPIGuide fn_egov_getcertlistSuccess Success');
    // json array 형태로 리턴된 데이타를 파싱하기 위해 json2.js 를 사용한다
    // 이외의 다른 String 2 JSON 모듈이 잇으면 그걸 사용해도 괜찬습니다.

    certListObj = JSON.parse(arg);
    var certList = '';
    
    /////////////////////////////////////////   	
    var list_html = "";
    for (var i = 0; i < certListObj.length; i++) {
        list_html += '<li> ' + 
        '<a href="#" onclick="fn_egov_sign_certdata('+i+')">' + certListObj[i].subjdn + '</a> ' +		
        '</li>';		
    }
    
    $.mobile.changePage("#certList", "slide", false, false);
    
    var theList = $('#theList');
    theList.html(list_html);
    theList.listview("refresh"); 
}

/**
 * 인증서 리스트 호출 실패 Callback function.
 * @returns
 * @type
*/
function fn_egov_getcertlistFail(errormsg) {
    console.log('DeviceAPIGuide fn_egov_getcertlistFail Fail');
    alert("인증서를 가져오는 도중 오류가 발생했습니다\n"+errormsg);
}

/**
 * 인증서 리스트 호출 function.
 * @returns getcertlist call back
 * @type
*/
function fn_egov_go_certlist() {
    var setDefine = ["oidname","issuer","name","subjdn","start","end"];
    
    // setDefine 에 지정된 리스트로 데이타를 요청한다
    window.plugins.magicxsign.getcertlist(fn_egov_getcertlistSuccess,  fn_egov_getcertlistFail, JSON.stringify(setDefine));
}

/**
 * 인증서 정보 innerhtmlArea 생성 function.
 * @returns innerhtmlArea 생성 후 로그인 화면 이동
 * @type
*/
function fn_egov_sign_certdata(iCertIndex) {
    // 인증서 선택후 화면에 FORM 문을 보여주기 위한 부분
    // 반드시 이 구조를 따를 필요는 없습니다.
    // 선택된 인증서의 INDEX 를 xsigncertindex 로 지정  form 문 밖에 hidden 벨류로 지정해주어야 합니다.
    // 그리고 선택된 인증서의 비밀번호를  xsigncertpassword 로 지정  form 문 밖에서 입력을 받아야 합니다.
    
    var signForm = '';
    signForm = "" 
        +certListObj[iCertIndex].subjdn+"<br>"
        +certListObj[iCertIndex].name+"<br>"
        +certListObj[iCertIndex].issuer+"<br>"
        +certListObj[iCertIndex].oidname+"<br>"
        +certListObj[iCertIndex].start+"<br>"
        +certListObj[iCertIndex].end+"<br>";
    
    var certInfo = $('#certInfo');
    certInfo.html(signForm);
    
    
    // 사용자가 선택한 인증서 INDEX (HIDDEN 벨류)
    var signIndex = '';
    signIndex = "" 
        +"<input type=hidden name='xsigncertindex' id='xsigncertindex' value='"+iCertIndex+"'/>";
    
    document.getElementById("innerhtmlArea").innerHTML=signIndex;
    
    $('#loginForm').each(function(){
        this.reset();
    });
    $.mobile.changePage("#login", "slide", false, false);
}

/**
 * 인증서 서명 function.
 * @returns 인증서 서명 성공 여부
 * @type  
*/
function fn_egov_login_member() {
    var setDefine = {};
    setDefine["plaintext"]=encodeURIComponent("usrId=&password=&name=");    // form Data    
    setDefine["certindex"]=document.getElementById("xsigncertindex").value; // 선택된 인증서 INDEX
    setDefine["certpassword"]=$("#loginPasswd").val();                      // 선택된 인증서 Password
    
    window.plugins.magicxsign.makesign(fn_egov_makesign_ok, fn_egov_makesign_fail, JSON.stringify(setDefine));
}

/**
 * Login Info List 화면 이동 function.
 * @returns 서버에 저장된 로그인 로그 정보를 요청받아 XML 리스트 반환한다.
 * @type  
*/
function fn_egov_go_loginInfoList() {
    //3G 사용시 과금이 발생 할 수 있다는 경고 메시지 표시
    if(!fn_egov_network_check(false)) {
        return;
    }
    
    $.mobile.changePage("#loginInfoList", "slide", false, false);
    
    var url = "/pki/xml/pkiInfoList.do";
    var accept_type = "xml";
    // get the data from server
    window.plugins.EgovInterface.post(url,accept_type, null, function(xmldata) {
        console.log('DeviceAPIGuide fn_egov_go_loginInfoList request Complete');
        var list_html = "";
        $(xmldata).find("pkiInfoList").each(function(){
            var dn = $(this).find("dn").text();
            var date = $(this).find("crtfcDt").text();
            var entrprsSeCode = $(this).find("entrprsSeCode").text().replace(/\s+$/, "");
            var entrprsSe = "NONE";
            if(entrprsSeCode == 'PKI01') {
                entrprsSe = "MagicXSign";
            } else if(entrprsSeCode == 'PKI02') {
                entrprsSe = "WizSign";
            } else if(entrprsSeCode == 'PKI03') {
                entrprsSe = "XecureSmart";
            }
            
            list_html += "<li><h3>subjdn : " + dn + "</h3>";
            list_html += "<p><strong>Date : " + date + "</strong></p>";
            list_html += "<p><strong>NPKI : " + entrprsSe + "</strong></p></li>";
            });
        var theList = $('#theLogList');
        theList.html(list_html);
        theList.listview("refresh");
        myScroll.refresh();
    });
}
