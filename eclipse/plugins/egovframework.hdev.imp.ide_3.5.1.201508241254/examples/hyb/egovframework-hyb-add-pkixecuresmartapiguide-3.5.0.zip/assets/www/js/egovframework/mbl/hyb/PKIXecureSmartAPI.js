/** 
 * @fileoverview 모바일 전자정부 하이브리드 앱 PKIXecureSmart API 가이드 프로그램 JavaScript
 * JavaScript. 
 *
 * @author 나신일
 * @version 1.0 
 */

/**
 * XecureSmartPlugin 객체 생성
 * 
 * @type XecureSmartPlugin
 */
var XecureSmart = new XecureSmartPlugin ();

/**
 * iScroll 객체 생성
 * 
 * @type iScroll
 */
var myScroll;

/*******************************************************************************
 * HTML 및 이벤트 관련 함수
 ******************************************************************************/

/**
 * 화면을 위한 관련 이벤트
 */
$(function(){
    $.validator.setDefaults({
        submitHandler: function() { 
            if($.mobile.activePage.is('#login')) {
                // 3G 사용시 과금이 발생 할 수 있다는 경고 메시지 표시
                if(!fn_egov_network_check(false)) {
                    return;
                }
                // 인증서 인증
                fn_egov_make_sign();
            }
        }
    });
    
    // validation check
    $("#loginForm").validate();
    
    $(document).on("pageshow", "#importanceList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapperInfo');
    });
    
    $(document).on("pageshow", "#certList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapper');
    });
    
    $(document).on("pageshow", "#loginInfoList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapperList');
    });
});

/**
 * PhoneGap 초기화 이벤트에서 호출하는 function
 * 
 * @returns iscroll 과 Back 버튼 event 추가
 * @type
 */
function DeviceAPIInit() {
    loaded('wrapperInfo');
    document.addEventListener("backbutton", backKeyDown, false);
}

/**
 * Android Back 버튼 클릭 이벤트 function.
 * 
 * @returns intro or importanceList 화면에서 종료하고 나머지 화면에선 back 처리
 * @type
 */
function backKeyDown(e) { 
    if($.mobile.activePage.is('#intro') || $.mobile.activePage.is('#importanceList')){
        
        e.preventDefault();
        navigator.app.exitApp();

    }else{
        navigator.app.backHistory();
    }
}

/**
 * iScroll 적용
 * @returns 
 * @type 
 */
function loaded(scrollTarget) {
    
    // Use this for high compatibility (iDevice + Android)
    setTimeout(function () {
        myScroll = new iScroll(scrollTarget, {
            onBeforeScrollStart : function(e) {
                var target = e.target;
                while (target.nodeType != 1)
                    target = target.parentNode;
    
                if (target.tagName != 'SELECT' && target.tagName != 'INPUT'
                        && target.tagName != 'TEXTAREA')
                    e.preventDefault();
            }
        });
    });

    document.addEventListener('touchmove', function(e) {
        e.preventDefault();
    }, false);
}

/**
 * 서명 성공 Callback function.
 * 
 * @returns 서명이 성공하면 사인데이터를 서버에 전달 한다.
 * @type
 */
function fn_egov_makesign_ok(arg)
{
    console.log('DeviceAPIGuide fn_egov_makesign_ok Success');
    if(arg == '') {
        alert('비밀번호 오류!!');
        return;
    }

    var signedData = arg;
    var url = "/pki/xml/addPKIInfo.do";
    var acceptType = "xml";
    var params = {uuid :  device.uuid,
            sign: signedData,
            entrprsSeCode: 'PKI03'};
    
    alert('Http Method:POST\nacceptType:'+ acceptType + '\n요청데이터:' + JSON.stringify(params));
    
    // get the data from server
    window.plugins.EgovInterface.post(url,acceptType, params, function(xmldata) {
        console.log('DeviceAPIGuide fn_egov_makesign_ok request Complete');
        alert('응답데이터:' + xmldata);
        if($(xmldata).find("resultState").text() == "OK"){	
            
            window.history.go(-2);
        }else{
            jAlert($(xmldata).find("resultMessage").text(), '오류', 'c');
        }
        
    });	
}

/**
 * 서명 실패 Callback function.
 * 
 * @returns
 * @type
 */
function fn_egov_makesign_fail(arg)
{
    console.log('DeviceAPIGuide fn_egov_makesign_fail Fail');
    alert ("fail : [" + result + "]");
}

/**
 * 인증서 리스트 호출 성공 Callback function.
 * 
 * @returns 리스트 생성
 * @type
 */
function fn_egov_getcerttree_success(result) {	
    console.log('DeviceAPIGuide fn_egov_getcerttree_success Success');
    $.mobile.loading("hide");
    var certInfoArray = result.split ("\t\n");

    var list_html = "";
    for (var certInfo in certInfoArray)
    {
        if (certInfoArray[certInfo].length == 0)
        {
            continue;
        }

        var certArray = certInfoArray[certInfo].split ("$");
        list_html += "<li> " +
        "<a href='#' onclick=\"fn_egov_sign_certdata('" + certArray[5] + "', '" + certArray[6] + "', '" + certArray[2] +"');\">" + certArray[2] + "</a> " +		
        "</li>";
    }
    
    $.mobile.changePage("#certList", "slide", false, false);
    
    var theList = $('#theList');
    theList.html(list_html);	
    theList.listview("refresh");
}

/**
 * 인증서 리스트 호출 실패 Callback function.
 * 
 * @returns
 * @type
 */
function fn_egov_getcerttree_fail(result) {
    console.log('DeviceAPIGuide fn_egov_getcerttree_fail Fail');
    $.mobile.loading("hide");
    alert ("fail : [" + result + "]");
}

/**
 * 인증서 리스트 호출 function.
 * 
 * @returns getCertTree call back
 * @type
 */
function fn_egov_go_certlist()
{
    $.mobile.loading("show");
    XecureSmart.getCertTree(fn_egov_getcerttree_success, fn_egov_getcerttree_fail, 2, 0, 5, '', '');
}

/**
 * 인증서 정보 innerhtmlArea 생성 function.
 * 
 * @returns innerhtmlArea 생성 후 로그인 화면 이동
 * @type
 */
function fn_egov_sign_certdata(issuerDN, certSerial, subjectDN)
{
    var signForm = '';
    signForm = "" 
        +"선택한 인증서 정보<br>"
        +issuerDN+"<br>"
        +subjectDN+"<br>"
        +certSerial+"<br>";
    
    var certInfo = $('#certInfo');
    certInfo.html(signForm);
    

    // 사용자가 선택한 인증서 INDEX (HIDDEN 벨류)
    var signIndex = '';
    signIndex = "" 
        +"<input type=hidden name='issuerDN' id='issuerDN' value='"+issuerDN+"'/>"
        +"<input type=hidden name='certSerial' id='certSerial' value='"+certSerial+"'/>";
    
    document.getElementById("innerhtmlArea").innerHTML=signIndex;
    
    $('#loginForm').each(function(){
        this.reset();
    });
   	$.mobile.changePage("#login", "slide", false, false);
}

/**
 * 서명하기 위한 function.
 * 
 * @returns 인증서 서명 성공 여부
 * @type
 */
function fn_egov_make_sign()
{
    XecureSmart.signDataCMS (fn_egov_makesign_ok, fn_egov_makesign_fail, document.getElementById("issuerDN").value, document.getElementById("certSerial").value, $("#loginPasswd").val(), "usrId=&password=&name=");		
}

/**
 * Login Info List 화면 이동 function.
 * 
 * @returns 서버에 저장된 로그인 로그 정보를 요청받아 XML 리스트 반환한다.
 * @type
 */
function fn_egov_go_loginInfoList()
{
    // 3G 사용시 과금이 발생 할 수 있다는 경고 메시지 표시
    if(!fn_egov_network_check(false)) {
        return;
    }
    
    $.mobile.changePage("#loginInfoList", "slide", false, false);
    
    var url = "/pki/xml/pkiInfoList.do";
    var accept_type = "xml";
    // get the data from server
    window.plugins.EgovInterface.post(url,accept_type, null, function(xmldata) {
        console.log('DeviceAPIGuide fn_egov_go_loginInfoList request Complete');
        var list_html = "";
        
        $(xmldata).find("pkiInfoList").each(function(){
            var dn = $(this).find("dn").text();
            var date = $(this).find("crtfcDt").text();
            var entrprsSeCode = $(this).find("entrprsSeCode").text().replace(/\s+$/, "");
            var entrprsSe = "NONE";
            if(entrprsSeCode == 'PKI01') {
                entrprsSe = "MagicXSign";
            } else if(entrprsSeCode == 'PKI02') {
                entrprsSe = "WizSign";
            } else if(entrprsSeCode == 'PKI03') {
                entrprsSe = "XecureSmart";
            }

            list_html += "<li><h3>subjdn : " + dn + "</h3>";
            list_html += "<p><strong>Date : " + date + "</strong></p>";
            list_html += "<p><strong>NPKI : " + entrprsSe + "</strong></p></li>";
            });
        var theList = $('#theLogList');
        theList.html(list_html);
        theList.listview("refresh");
        myScroll.refresh();
    });
}